import { motion } from 'motion/react';
import { servicesData } from '../data';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SEO from '../components/SEO';

export default function Services() {
  return (
    <div className="pt-20">
      <SEO 
        title="Services | Waterproofing, Roofing & Property Maintenance in Eswatini" 
        description="Explore our comprehensive property services in Eswatini, including premium waterproofing, roof restorations, painting, epoxy flooring, and property maintenance."
        url="https://liquidrubbertech.co.za/services"
        schema={[
          {
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            "name": "Property Services - Liquid Rubber Tech",
            "url": "https://liquidrubbertech.co.za/services",
            "description": "Explore our comprehensive property services in Eswatini, including premium waterproofing, roof restorations, painting, epoxy flooring, and property maintenance.",
            "provider": {
              "@type": "HomeAndConstructionBusiness",
              "name": "Liquid Rubber Tech Investments",
              "url": "https://liquidrubbertech.co.za/"
            },
            "hasOfferCatalog": {
              "@type": "OfferCatalog",
              "name": "Construction & Waterproofing Services",
              "itemListElement": servicesData.map((service, index) => ({
                "@type": "Offer",
                "position": index + 1,
                "itemOffered": {
                  "@type": "Service",
                  "name": service.title,
                  "description": service.description,
                  "url": `https://liquidrubbertech.co.za/services/${service.id}`
                }
              }))
            }
          },
          {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
              {
                "@type": "ListItem",
                "position": 1,
                "name": "Home",
                "item": "https://liquidrubbertech.co.za/"
              },
              {
                "@type": "ListItem",
                "position": 2,
                "name": "Services",
                "item": "https://liquidrubbertech.co.za/services"
              }
            ]
          }
        ]}
      />
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-bold mb-6"
          >
            Our <span className="text-gradient">Expertise</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-400 max-w-2xl mx-auto mb-16"
          >
            Comprehensive construction, restoration, and waterproofing solutions.
          </motion.p>

                    <div className="space-y-24">
            {['ROOFING & WATERPROOFING', 'PROPERTY FINISHING & RENOVATION', 'CONSTRUCTION & MAINTENANCE'].map((category, catIndex) => (
              <div key={category} className="text-left">
                <motion.h2 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="text-2xl md:text-3xl font-display font-bold mb-8 border-b border-white/10 pb-4"
                >
                  <span className="text-brand-green mr-2">//</span> {category}
                </motion.h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {servicesData.filter(s => s.category === category).map((service, index) => (
                    <motion.div
                      key={service.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.05 }}
                      className="glass-panel overflow-hidden group text-left flex flex-col h-full"
                    >
                      <div className="h-[400px] overflow-hidden relative">
                        <div className="absolute inset-0 bg-brand-dark/40 z-10 group-hover:bg-brand-dark/10 transition-colors duration-500"></div>
                        <img src={service.image} alt={`${service.title} services in Eswatini`} loading="lazy" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                      </div>
                      <div className="p-6 flex-grow flex flex-col">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                            <service.icon className="w-5 h-5 text-brand-green" />
                          </div>
                          <h3 className="text-xl font-bold">{service.title}</h3>
                        </div>
                        <p className="text-gray-400 text-sm leading-relaxed mb-6 flex-grow">{service.description}</p>
                        <Link to={`/services/${service.id}`} className="inline-flex items-center text-sm font-bold text-white group-hover:text-brand-green transition-colors w-max">View Details <span className="sr-only">about {service.title}</span> <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
